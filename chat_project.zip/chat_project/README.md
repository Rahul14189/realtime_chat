# Real Time Chat Application

### Note** 
The project is missing proper comment within the code. And it is more backend specific project, so the UI segment is 
not very user attractive and convenient. However, to implement Websocket based feature, it comprises more of javascript 
based implementation.

## Overview:
This application provides a real-time chat platform for users within a single organization. 
It allows users to register, login, create and join group chats, and send messages to individual users or groups. 
The application features include:
1) User Authentication: Secure login and registration processes.
2) Profile Management: Users can update upload avatars. However, details can be updated from the admin panel only.
3) Direct Messaging: One-on-one messaging between users.
4) Group Chats: Creation and management of group chats.
5) Real-Time Updates: Instantaneous message delivery and typing indicators.
6) Message Editing: Users can edit their sent messages within a 5-minute window. [not implemented]
7) Unread Message Notifications: Notification for unread messages.

## Technologies and Tools:
1) Frontend: Html, javascript and CSS for building the user interface.
2) Backend: Python, Django for handling API requests and server-side logic.
3) Database: Sqlite3 for storing user data, messages, and group information.
4) Real-Time Communication: Websocket for real-time message delivery and updates.
5) Authentication: Inbuilt django basic auth for user authentication and authorization.


## Installation and Setup
1) Clone the Repository:
    #### Git clone:
    Coming soon.
    #### Zip File:
    Unzip the zip file into a folder.
2) Install Dependencies And Run Application:
    #### With Docker:
    ```
    cd chat_project
    docker compose build
    docker compose up -d
    ```
   #### Without Docker:
    Coming Soon.
   #### Demo User:
    i) UserName = rahul
       password = 1234
    ii) UserName = vicky
       password = 1234 

## Contributor:
The project is in its very early phase, created by Rahul Jha.

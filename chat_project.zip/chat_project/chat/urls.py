# from django.urls import path
# from .views import chat_list, chat_detail, create_group_chat, signup
#
# urlpatterns = [
#     path('', chat_list, name='chat-list'),
#     path('chat/<int:chat_id>/', chat_detail, name='chat-detail'),
#     path('create_group_chat/', create_group_chat, name='create-group-chat'),
#     path('signup/', signup, name='signup'),  # Sign-up URL
# ]



from django.urls import path
from .views import chat_list, chat_detail, create_group_chat, direct_message, update_profile, signup, user_search, start_private_chat

urlpatterns = [
    path('', chat_list, name='chat-list'),
    path('chat/<int:chat_id>/', chat_detail, name='chat-detail'),
    path('create_group_chat/', create_group_chat, name='create-group-chat'),
    path('dm/<str:username>/', direct_message, name='direct-message'),  # Direct message URL
    path('profile/', update_profile, name='profile'),  # Profile update URL
    path('signup/', signup, name='signup'),  # Sign-up URL
    path('user_search/', user_search, name='user-search'),
    path('start_private_chat/<int:user_id>/', start_private_chat, name='start-private-chat'),
]


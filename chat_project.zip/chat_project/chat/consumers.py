from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
import json
import datetime
from chat_project.utils.logging import LOGGING
import logging.config



logging.config.dictConfig(LOGGING)




class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        try:
            self.chat_id = self.scope['url_route']['kwargs']['chat_id']
            self.room_group_name = f'chat_{self.chat_id}'

            await self.channel_layer.group_add(
                self.room_group_name,
                self.channel_name
            )

            await self.accept()
        except Exception as e:
            logging.error(f"Exception occurred at connect as: {e}")

    async def disconnect(self, close_code):
        try:
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )
            if close_code == 1000:
                logging.debug("WebSocket closed cleanly")
            else:
                logging.debug(f"WebSocket closed unexpectedly with code {close_code}")
            await self.close(close_code)
        except Exception as e:
            logging.error(f"Exception occurred at disconnect as: {e}")

    async def receive(self, text_data):
        try:
            text_data_json = json.loads(text_data)
            action = text_data_json.get('action')

            # if action == 'ping':
            #     print(f"Connection is alive")
            #     await self.channel_layer.group_send(
            #         self.room_group_name,
            #         {
            #             'message': 'Connection is alive',
            #             'type': 'ping',
            #             'action': 'ping',
            #         }
            #     )
            #     return

            if action == 'send_message':
                # Avoiding premature import
                from .models import Chat, Message

                message = text_data_json['message']
                sender = self.scope['user'].username
                timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                # chat = await Chat.objects.get(id=self.chat_id)
                # await Message.objects.create(
                #     chat=chat,
                #     sender=self.scope['user'],
                #     content=message
                # )
                logging.debug(f"Saving message to database")
                await self.save_message(message)

                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_message',
                        'action': 'chat_message',
                        'message': message,
                        'sender': sender,
                        'timestamp': timestamp
                    }
                )
            elif action == 'typing':
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_typing',
                        'action': 'chat_typing',
                        'sender': self.scope['user'].username
                    }
                )
            elif action == 'seen':
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_seen',
                        'action': 'chat_seen',
                        'sender': self.scope['user'].username
                    }
                )
        except Exception as e:
            logging.error(f"Exception occurred at receive as: {e}")

    async def chat_message(self, event):
        try:
            message = event['message']
            sender = event['sender']

            await self.send(text_data=json.dumps({
                'message': message,
                'sender': sender,
                'timestamp': event['timestamp']
            }))
        except Exception as e:
            logging.error(f"Exception occurred at chat_message as: {e}")

    async def chat_typing(self, event):
        try:
            sender = event['sender']

            await self.send(text_data=json.dumps({
                'action': 'typing',
                'type': 'typing',
                'sender': sender
            }))
        except Exception as e:
            logging.error(f"Exception occurred at chat_typing as: {e}")

    async def chat_seen(self, event):
        try:
            sender = event['sender']
            await self.send(text_data=json.dumps({
                'action': 'seen',
                'type': 'seen',
                'sender': sender
            }))
        except Exception as e:
            logging.error(f"Exception occurred at chat_seen as: {e}")

    # async def ping_message(self, event):
    #     try:
    #         message = event['message']
    #         await self.send(text_data=json.dumps({
    #             'action': 'ping',
    #             'type': 'ping',
    #             'message': message
    #         }))
    #     except Exception as e:
    #         logging.error(f"Exception occurred at ping_message as: {e}")

    @database_sync_to_async
    def save_message(self, message):
        try:
            from .models import Chat, Message
            chat = Chat.objects.get(id=self.chat_id)  # Assuming room_name is the Chat ID
            return Message.objects.create(chat=chat, sender=self.scope['user'], content=message)
        except Exception as e:
            logging.error(f"Exception occurred at save_message as: {e}")

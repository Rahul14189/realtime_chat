from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Chat, Message, Profile
from django.contrib.auth.models import User
from .forms import MessageForm, GroupChatForm, ProfileForm
from django.db.models import Q
from chat_project.utils.logging import LOGGING
import logging.config
from django.db.models import Q
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth import logout



logging.config.dictConfig(LOGGING)



def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def chat_list(request):
    chats = Chat.objects.filter(participants=request.user)
    return render(request, 'chat/chat_list.html', {'chats': chats})

@login_required
def chat_detail(request, chat_id):
    chat = get_object_or_404(Chat, id=chat_id)

    if request.user not in chat.participants.all():
        return redirect('chat-list')

    if request.method == 'POST':
        logging.info(f"saving message")
        print(f"saving message of {request.user}")
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.chat = chat
            message.sender = request.user
            message.save()
            return redirect('chat-detail', chat_id=chat_id)
    else:
        form = MessageForm()

    messages = chat.messages.order_by('-timestamp')

    print(f"Chat ID: {chat.id}, Number of messages: {messages.count()}")
    for msg in messages:
        print(f"Message by {msg.sender.username}: {msg.content} at {msg.timestamp}")

    return render(request, 'chat/chat_detail.html', {
        'chat': chat,
        'messages': messages,
        'form': form
    })

@login_required
def create_group_chat(request):
    if request.method == 'POST':
        form = GroupChatForm(request.POST)
        if form.is_valid():
            chat = form.save(commit=False)
            chat.is_group_chat = True
            chat.save()
            chat.participants.add(request.user)
            return redirect('chat-list')
    else:
        form = GroupChatForm()
    return render(request, 'chat/create_group_chat.html', {'form': form})

@login_required
def direct_message(request, username):
    other_user = get_object_or_404(User, username=username)
    chat = Chat.objects.filter(participants=request.user).filter(participants=other_user).first()

    if not chat:
        chat = Chat.objects.create(is_group_chat=False)
        chat.participants.add(request.user, other_user)

    return redirect('chat-detail', chat_id=chat.id)

@login_required
def update_profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = ProfileForm(instance=request.user.profile)
    return render(request, 'chat/profile.html', {'form': form})

@login_required
def user_search(request):
    query = request.GET.get('query')
    users = User.objects.filter(Q(username__icontains=query) & ~Q(id=request.user.id))
    return render(request, 'chat/user_search_results.html', {'users': users})

@login_required
def start_private_chat(request, user_id):
    user = get_object_or_404(User, id=user_id)
    chat, created = Chat.objects.get_or_create(is_group_chat=False)
    chat.participants.add(request.user, user)
    return redirect('chat-detail', chat_id=chat.id)

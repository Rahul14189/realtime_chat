from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from chat import views

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('accounts/', include('django.contrib.auth.urls')),
#     path('', include('chat.urls')),
# ]

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.chat_list, name='chat-list'),
    path('chat/<int:chat_id>/', views.chat_detail, name='chat-detail'),
    path('create_group_chat/', views.create_group_chat, name='create-group-chat'),
    path('signup/', views.signup, name='signup'),
    path('dm/<str:username>/', views.direct_message, name='direct-message'),
    path('profile/', views.update_profile, name='profile'),
    path('signup/', views.signup, name='signup'),
    path('user_search/', views.user_search, name='user-search'),
    path('start_private_chat/<int:user_id>/', views.start_private_chat, name='start-private-chat'),
    path('accounts/', include('django.contrib.auth.urls')),
    # path('logout/', views.logout_view, name='logout'),
]

if settings.DEBUG:
    urlpatterns += + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


